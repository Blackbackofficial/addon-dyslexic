const btn = document.getElementById('voicerEvent');
if (btn) {
    btn.click();
}