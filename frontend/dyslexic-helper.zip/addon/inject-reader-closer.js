var btn = document.getElementsByClassName('rr-button--close').item(0)
if (btn) {
    btn.click()
}